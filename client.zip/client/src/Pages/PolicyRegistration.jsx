import React, { useState } from "react";
import Sidebar from '../Components/Sidebar'; // Adjust the path as necessary

export default function PolicyRegistration() {
  const [formData, setFormData] = useState({
    policyNumber: "",
    policyName: "",
    policyType: "Life Insurance",
    provider: "",
    startDate: "",
    endDate: "",
    installmentType: "Monthly",
    installmentAmount: "",
    nextInstallmentDate: ""
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(formData); // You can handle form submission logic here
  };

  return (
    <div className="flex min-h-screen bg-gray-100">
      <Sidebar /> {/* Add Sidebar */}

      {/* Main Content */}
      <div className="flex-1 p-10">
        <form
          onSubmit={handleSubmit}
          className="bg-white p-6 rounded-lg shadow-md w-full max-w-lg mx-auto"
        >
          <h2 className="text-2xl font-semibold text-blue-600 mb-6 text-center">
            Policy Registration Form
          </h2>

          {/* Policy Number */}
          <div className="mb-4">
            <label className="block text-gray-700">Policy Number</label>
            <input
              type="text"
              name="policyNumber"
              value={formData.policyNumber}
              onChange={handleChange}
              className="w-full p-2 mt-1 border rounded-md focus:ring focus:ring-blue-200"
              required
            />
          </div>

          {/* Policy Name */}
          <div className="mb-4">
            <label className="block text-gray-700">Policy Name</label>
            <input
              type="text"
              name="policyName"
              value={formData.policyName}
              onChange={handleChange}
              className="w-full p-2 mt-1 border rounded-md focus:ring focus:ring-blue-200"
              required
            />
          </div>

          {/* Policy Type */}
          <div className="mb-4">
            <label className="block text-gray-700">Policy Type</label>
            <select
              name="policyType"
              value={formData.policyType}
              onChange={handleChange}
              className="w-full p-2 mt-1 border rounded-md focus:ring focus:ring-blue-200"
            >
              <option value="Life Insurance">Life Insurance</option>
              <option value="Health Insurance">Health Insurance</option>
              <option value="Property Insurance">Property Insurance</option>
            </select>
          </div>

          {/* Provider */}
          <div className="mb-4">
            <label className="block text-gray-700">Provider</label>
            <input
              type="text"
              name="provider"
              value={formData.provider}
              onChange={handleChange}
              className="w-full p-2 mt-1 border rounded-md focus:ring focus:ring-blue-200"
              required
            />
          </div>

          {/* Start Date */}
          <div className="mb-4">
            <label className="block text-gray-700">Start Date</label>
            <input
              type="date"
              name="startDate"
              value={formData.startDate}
              onChange={handleChange}
              className="w-full p-2 mt-1 border rounded-md focus:ring focus:ring-blue-200"
              required
            />
          </div>

          {/* End Date */}
          <div className="mb-4">
            <label className="block text-gray-700">End Date</label>
            <input
              type="date"
              name="endDate"
              value={formData.endDate}
              onChange={handleChange}
              className="w-full p-2 mt-1 border rounded-md focus:ring focus:ring-blue-200"
              required
            />
          </div>

          {/* Installment Type */}
          <div className="mb-4">
            <label className="block text-gray-700">Installment Type</label>
            <select
              name="installmentType"
              value={formData.installmentType}
              onChange={handleChange}
              className="w-full p-2 mt-1 border rounded-md focus:ring focus:ring-blue-200"
            >
              <option value="Monthly">Monthly</option>
              <option value="Quarterly">Quarterly</option>
              <option value="Annually">Annually</option>
            </select>
          </div>

          {/* Installment Amount */}
          <div className="mb-4">
            <label className="block text-gray-700">Installment Amount</label>
            <input
              type="number"
              name="installmentAmount"
              value={formData.installmentAmount}
              onChange={handleChange}
              className="w-full p-2 mt-1 border rounded-md focus:ring focus:ring-blue-200"
              required
            />
          </div>

          {/* Next Installment Date */}
          <div className="mb-4">
            <label className="block text-gray-700">Next Installment Date</label>
            <input
              type="date"
              name="nextInstallmentDate"
              value={formData.nextInstallmentDate}
              onChange={handleChange}
              className="w-full p-2 mt-1 border rounded-md focus:ring focus:ring-blue-200"
              required
            />
          </div>

          {/* Submit Button */}
          <div className="text-center">
            <button
              type="submit"
              className="w-full bg-blue-600 text-white p-2 rounded-md hover:bg-blue-700 transition duration-300"
            >
              Submit
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
