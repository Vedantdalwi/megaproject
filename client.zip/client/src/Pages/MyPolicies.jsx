// src/Pages/MyPoliciesPage.jsx
import React from 'react';
import { useNavigate } from 'react-router-dom';
import Sidebar from '../Components/Sidebar'; // Adjust the path as necessary

const MyPoliciesPage = () => {
  const navigate = useNavigate();

  const handleAddPolicy = () => {
    navigate('/policy-registration');
  };

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      
      {/* Main Content */}
      <div className="flex-1 p-10 bg-gray-100">
        <h1 className="text-3xl font-bold mb-6">My Policies</h1>
        
        {/* Centered Add Policy Button */}
        <div className="flex justify-center mb-6">
          <button
            onClick={handleAddPolicy}
            className="bg-blue-600 text-white px-6 py-3 rounded-full shadow-lg hover:bg-blue-700 transition duration-300 transform hover:scale-105"
          >
            Add Policy
          </button>
        </div>

        {/* My Policies Content */}
        <div className="bg-white shadow-lg p-6 rounded-lg">
          <p className="text-lg">
            This page will display your insurance policies.
          </p>
          {/* You can add more content here, like a list of policies */}
        </div>
      </div>
    </div>
  );
};

export default MyPoliciesPage;
